# Nagaraju Pendyals Website

A responsive emerald-green and gold starter website for Nagaraju Pendyals, Tirupati.

## Open on your computer
1. Extract this ZIP file.
2. Open the extracted `nagaraju-pendyals-website` folder in VS Code.
3. Open `index.html`.
4. If Live Server is installed, click **Go Live**. Otherwise, double-click `index.html` in File Explorer to open it in your browser.

## Your event photo
Your uploaded photo is included at `images/ganesh-festival-pandal.jpg` and displayed in the Gallery and home-page background.

## Before publishing
1. Open `config.js`.
2. Add the business WhatsApp number using country code and digits only, e.g. `919876543210`.
3. Add the real phone number and exact business address.
4. Replace/add more gallery photos in the `images` folder and update the gallery section in `index.html`.
5. Test the booking enquiry on a phone before sharing the website.

## Notes
- Booking enquiries open WhatsApp; this starter version does not store bookings in an online database or include an admin dashboard.
- The Maps link currently searches Tirupati generally. Update it to the exact business location when available.
- Use only genuine business photographs and customer reviews you have permission to publish.
