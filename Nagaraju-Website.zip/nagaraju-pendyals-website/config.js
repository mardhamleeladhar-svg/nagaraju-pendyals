// Update these values with the real business contact details before publishing.
window.BUSINESS_CONFIG = {
  whatsappNumber: "", // Example: "919876543210" (country code + number, digits only)
  phoneNumber: "",
  businessName: "Nagaraju Pendyals",
  city: "Tirupati, Andhra Pradesh"
};
