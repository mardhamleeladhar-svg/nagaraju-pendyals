const config = window.BUSINESS_CONFIG || {};
const waNumber = (config.whatsappNumber || "").replace(/\D/g, "");
function waLink(message) {
  return waNumber ? `https://wa.me/${waNumber}?text=${encodeURIComponent(message)}` : "";
}
function setWhatsAppLinks() {
  const link = waLink("Hello Nagaraju Pendyals, I would like to enquire about event arrangements.");
  ["contactWhatsApp", "floatingWhatsApp"].forEach(id => {
    const el = document.getElementById(id);
    if (el) { el.href = link || "#booking"; el.target = link ? "_blank" : "_self"; el.rel = "noopener"; }
  });
}
document.querySelector(".menu-toggle")?.addEventListener("click", () => {
  const nav = document.getElementById("nav");
  const open = nav.classList.toggle("open");
  document.querySelector(".menu-toggle").setAttribute("aria-expanded", String(open));
});
document.querySelectorAll("#nav a").forEach(a => a.addEventListener("click", () => document.getElementById("nav").classList.remove("open")));
document.getElementById("year").textContent = new Date().getFullYear();
document.getElementById("bookingForm").addEventListener("submit", event => {
  event.preventDefault();
  const data = new FormData(event.currentTarget);
  const message = [
    `Hello ${config.businessName || "Nagaraju Pendyals"}, I would like to enquire about an event.`,
    `Name: ${data.get("name")}`, `Phone: ${data.get("phone")}`, `Event: ${data.get("event")}`,
    `Date: ${data.get("date") || "Not specified"}`, `Venue: ${data.get("venue") || "Not specified"}`,
    `Requirements: ${data.get("message") || "Not specified"}`
  ].join("\\n");
  const url = waLink(message);
  const status = document.getElementById("formMessage");
  if (url) { window.open(url, "_blank", "noopener"); status.textContent = "Your WhatsApp enquiry is ready. Please press Send in WhatsApp."; }
  else { status.textContent = "Please add your WhatsApp number in config.js, then try again."; }
});
setWhatsAppLinks();
